package com.bit.util;

public class BitURL {

	public static final String TRADE_BTC_USD_URL = "https://www.gdax.com/trade/BTC-USD";
	public static final String TRADE_BCH_USD_URL = "https://www.gdax.com/trade/BCH-USD";
	public static final String TRADE_ETH_USD_URL = "https://www.gdax.com/trade/ETH-USD";
	public static final String TRADE_LTC_USD_URL = "https://www.gdax.com/trade/LTC-USD";

	public static final String FILLS_BTC_USD_URL = "https://www.gdax.com/orders/fills/BTC-USD";
	public static final String FILLS_BCH_USD_URL = "https://www.gdax.com/orders/fills/BCH-USD";
	public static final String FILLS_ETH_USD_URL = "https://www.gdax.com/orders/fills/ETH-USD";
	public static final String FILLS_LTC_USD_URL = "https://www.gdax.com/orders/fills/LTC-USD";
	
}
