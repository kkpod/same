package com.bit.util;

public class BITPRODUCT {
	public static final String BTCUSD = "BTC-USD";
	public static final String BCHUSD = "BTC-USD";
	public static final String ETHUSD = "ETH-USD";
	public static final String LTCUSD = "LTC-USD";
}
