package com.bit.util;

public enum BITYPE {
	BTC,
	BCH,
	ETH,
	LTC
}
