package com.bit.coin;

import java.io.IOException;
import java.util.logging.Logger;

public class Test {
	
	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Wonder.... ");
		
		try {
            MyLogger.setup();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Problems with creating the log files");
        }
        // set the LogLevel to Info, severe, warning and info will be written
        // finest is still not written
        LOGGER.info("Info Log");
        LOGGER.finest("Really not important");		

        for (int i=0; i<=10; i++) {
        	try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	LOGGER.info("..............." + i);
        }
	}

}
