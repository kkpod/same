package com.bit.coin;

import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class MyClass {
    private static final Logger log = Logger.getLogger(MyClass.class.getName());
    public String hello(String greetings, String name) {
        // entering will be logged as FINER
        log.entering(MyClass.class.getName(), "hello", new Object[]{greetings, name});

        // lambdas
        log.finest(() -> "finest: " + LocalDateTime.now());
        log.finer(() -> "finer: " + LocalDateTime.now());
        log.fine(() -> "fine: " + LocalDateTime.now());
        log.info(() -> "info: " + LocalDateTime.now());
        log.warning(() -> "warning: " + LocalDateTime.now());
        log.severe(() -> "severe: " + LocalDateTime.now());

        // exception logging

        // throwing will be logged as FINER
        log.throwing(MyClass.class.getName(), "hello", new Exception("test"));

        // exception + message logging with lambda
        log.log(Level.FINEST, new Exception("test"), () -> String.format("arg=%s", name));

        // exception + parameter logging with LogRecord
        final LogRecord record = new LogRecord(Level.FINEST, "arg={0}");
        record.setThrown(new Exception("test"));
        record.setLoggerName(log.getName()); // logger name will be null unless this
        record.setParameters(new Object[]{name});
        log.log(record);

        final String rc = greetings + ", " + name;

        // exiting will be logged as FINER
        log.exiting(MyClass.class.getName(), "hello", rc);
        return rc;
    }
}