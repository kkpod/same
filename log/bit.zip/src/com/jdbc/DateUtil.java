package com.jdbc;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
 
public class DateUtil {
 
	public static void main(String[] args) {
		Date date = convertToDate("2018-01-13T11:15:38.498Z");
		System.out.println(date.toString());
		System.out.println(date.getTime());
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		System.out.println(sqlDate.getTime());
		//Date newDate = result.getTimestamp("VALUEDATE");
		System.out.println();
	}
    // List of all date formats that we want to parse.
    // Add your own format here.
    private static List<SimpleDateFormat> 
            dateFormats = new ArrayList<SimpleDateFormat>() {
		private static final long serialVersionUID = 1L; 
		{							//2018-01-13T11:15:38.498Z
            add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"));
            add(new SimpleDateFormat("M/dd/yyyy"));
            add(new SimpleDateFormat("dd.M.yyyy"));
            add(new SimpleDateFormat("M/dd/yyyy hh:mm:ss a"));
            add(new SimpleDateFormat("dd.M.yyyy hh:mm:ss a"));
            add(new SimpleDateFormat("dd.MMM.yyyy"));
            add(new SimpleDateFormat("dd-MMM-yyyy"));
        }
    };
 
    /**
     * Convert String with various formats into java.util.Date
     * 
     * @param input
     *            Date as a string
     * @return java.util.Date object if input string is parsed 
     *          successfully else returns null
     */
    public static Date convertToDate(String input) {
    	if (input != null) {
        	input = input.replace("T", " ");
        	input = input.replace("Z", "");
    	}
    	
        Date date = null;
        if(null == input) {
            return null;
        }
        for (SimpleDateFormat format : dateFormats) {
            try {
            	format.setLenient(false);
                date = format.parse(input);
            } catch (ParseException e) {
                //Shhh.. try other formats
            }
            if (date != null) {
                break;
            }
        }
 
        return date;
    }
    
}