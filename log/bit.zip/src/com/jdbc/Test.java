package com.jdbc;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Test {

	public static void main(String[] args) throws ParseException {

		System.out.println((new ArrayList<>()).size());
		
		double d = 100.80;
		String dStr = d + "";
		if (dStr.endsWith(".01")) {
			System.out.println("Below 850");
		} else {
			System.out.println("Above 850");
		}

		
//		System.out.println(Calendar.getInstance().getTime());
//		System.out.println(getFillRecords().get(0)[0]);
		
		
//		String xlsDate  = "2018-01-12T15:55:45.985Z";
//		String uiDate = "06:29:30 pm - Jan 19, 2018";
//		
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//		dateFormat.setLenient(false);
//    	Date date = dateFormat.parse(xlsDate.replace("T", " ").replace("Z", ""));
//		System.out.println(date);
//		
		
		
		// TODO Auto-generated method stub
//		String currentPrice = "2,532.98 USD";
//		String onlyDollar = currentPrice.substring(0,currentPrice.indexOf("."));
//		int onlyDollarInt = NumberFormat.getNumberInstance(java.util.Locale.US).parse(onlyDollar).intValue();
//		System.out.println(onlyDollarInt);
//		
		
//		
//		int limitInitPrice = (int) Math.round(2493 * 1.002 + 0.5);
//		System.out.println(limitInitPrice);

//		int buyIndicator = 25;
//		System.out.println(buyIndicator % 25 == 0);
		
		
		/*
		WebElement ul_element = driver.findElement(By.xpath("//ul[@class='list-unstyled']"));
        List<WebElement> li_All = ul_element.findElements(By.tagName("li"));
        System.out.println(li_All.size());
        for(int i = 0; i < li_All.size(); i++){
            System.out.println(li_All.get(i).getText());
        }
        //OR
        for(WebElement element : li_All){
            System.out.println(element.getText());
        }
        
        */
	}

}
