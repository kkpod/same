package com.csv;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bit.coin.Trade;
import com.bit.util.BITYPE;

public class OrderStatusDAO {

	public static void main(String[] args) {
//		initiateLoad();
		
		getOrdersToBePlaced(BITYPE.ETH);
	}
	
	public static OrdersToBePlaced getOrdersToBePlaced(BITYPE bitype) {
		OrdersToBePlaced ordersToBePlaced = null;
		try {
			ordersToBePlaced = checkOrderStatus(bitype);
			
			System.out.println("RecentBUYs : " + ordersToBePlaced.getRecentBuyPrices());
			System.out.println("RecentSELLs : " + ordersToBePlaced.getRecentSellPrices());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ordersToBePlaced;
	}
	
	
	private static OrdersToBePlaced checkOrderStatus(BITYPE bitype) throws Exception {
		OrdersToBePlaced ordersToBePlaced = new OrdersToBePlaced();
		Statement stmt = null;
		Connection con = null;
		
		try {
			con = DAOConnection.getCon();
			con.setAutoCommit(false);

			stmt = con.createStatement(
		    	         ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

			// Get previousMaxIds
			ResultSet previousMaxOrderIdsRS = stmt.executeQuery("SELECT * FROM bits.ordersstatus where sizeUnit = '" + bitype.name() + "'");
			previousMaxOrderIdsRS.next();
			int lastBuyOder = previousMaxOrderIdsRS.getInt("lastBuyOder");
			int lastSellOder = previousMaxOrderIdsRS.getInt("lastSellOder");

			// Get all BUY records and their Prices which are executed after Previous BUY order.
			ResultSet recentBuyOrdersRS = stmt.executeQuery("select * from bits.order where tradeId>" + lastBuyOder + " and side='BUY' and sizeUnit = '" + bitype.name() + "'");
			List<String> recentBuyPrices = new ArrayList<>();
			List<Trade> recentBuyTrades = new ArrayList<>();
			while (recentBuyOrdersRS.next()) {
	            String price = recentBuyOrdersRS.getString("price");
	            recentBuyPrices.add(price);
	            
	            String size = recentBuyOrdersRS.getString("size");
	            Trade buyTrade = new Trade();
	            buyTrade.setPrice(price);
	            buyTrade.setSize(size);
	            recentBuyTrades.add(buyTrade);
			}
			
			// If count of recentBuy orders is greater than 0, Get Max orderId
			Integer maxBuyId = lastBuyOder;
			if (recentBuyPrices.size() > 0) {
				ResultSet currentMaxBuyOrderIdRS = stmt.executeQuery("SELECT MAX(tradeId) maxBuyId FROM bits.`order` where side='BUY' and sizeUnit = '" + bitype.name() + "'");
				currentMaxBuyOrderIdRS.next();
				maxBuyId = currentMaxBuyOrderIdRS.getInt("maxBuyId");
			}
			
			// Get all SELL records and their Prices which are executed after Previous SELL order.
			ResultSet recentSellOrdersRS = stmt.executeQuery("select * from bits.order where tradeId>" + lastSellOder + " and side='SELL' and sizeUnit = '" + bitype.name() + "'");
			List<String> recentSellPrices = new ArrayList<>();
			List<Trade> recentSellTrades = new ArrayList<>();
			while (recentSellOrdersRS.next()) {
	            String price = recentSellOrdersRS.getString("price");
	            recentSellPrices.add(price);

	            String size = recentSellOrdersRS.getString("size");
	            Trade sellTrade = new Trade();
	            sellTrade.setPrice(price);
	            sellTrade.setSize(size);
	            recentSellTrades.add(sellTrade);
			}

			// If count of recentBuy orders is greater than 0, Get Max orderId
			Integer maxSellId = lastSellOder;
			if (recentSellPrices.size() > 0) {
				ResultSet currentMaxSellOrderIdRS = stmt.executeQuery("SELECT MAX(tradeId) maxSellId FROM bits.`order` where side='SELL' and sizeUnit = '" + bitype.name() + "'");
				currentMaxSellOrderIdRS.next();
				maxSellId = currentMaxSellOrderIdRS.getInt("maxSellId");
			}

			if (recentBuyPrices.size() > 0 || recentSellPrices.size() > 0) {
				int updateCount = stmt.executeUpdate("UPDATE bits.ordersstatus SET lastBuyOder=" + maxBuyId + ", lastSellOder=" + maxSellId + " WHERE  sizeUnit = '" + bitype.name() + "'");
			}
			
			ordersToBePlaced.setRecentBuyPrices(recentBuyPrices);
			ordersToBePlaced.setRecentSellPrices(recentSellPrices);

			ordersToBePlaced.setBuyTrades(recentBuyTrades);
			ordersToBePlaced.setSellTrades(recentSellTrades);

			con.commit();
		} catch (Exception e) {
			con.rollback();
			e.printStackTrace();
			throw new Exception(
					"Error occured while loading data from file to database."
							+ e.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
			if (null != con)
				con.close();
		}
		return ordersToBePlaced;
	}
}
