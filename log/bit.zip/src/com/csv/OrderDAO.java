package com.csv;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.bit.util.BITPRODUCT;
import com.bit.util.BITYPE;
import com.jdbc.DateUtil;
import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

/**
 * 
 * @author viralpatel.net
 * 
 */
public class OrderDAO {

	//private static final String SQL_INSERT = "INSERT INTO ${table}(${keys}) VALUES(${values})";
	private static final String SQL_INSERT = "INSERT INTO bits.`${table}` VALUES(${values})";
	private static final String TABLE_REGEX = "\\$\\{table\\}";
	private static final String KEYS_REGEX = "\\$\\{keys\\}";
	private static final String VALUES_REGEX = "\\$\\{values\\}";

	private Connection connection;
	private char seprator;

	/**
	 * Public constructor to build CSVLoader object with
	 * Connection details. The connection is closed on success
	 * or failure.
	 * @param connection
	 */
	public OrderDAO(Connection connection) {
		this.connection = connection;
		this.seprator = ',';
	}
	
	/**
	 * Parse CSV file using OpenCSV library and load in 
	 * given database table. 
	 * @param csvFile Input CSV file
	 * @param tableName Database table name to import data
	 * @param truncateBeforeLoad Truncate the table before inserting 
	 * 			new records.
	 * @throws Exception
	 */
	public void loadData(String tableName,
			boolean truncateBeforeLoad, List<String[]> fills) throws Exception {

		if(null == this.connection) {
			throw new Exception("Not a valid connection.");
		}

		String questionmarks = StringUtils.repeat("?,", 10);
		questionmarks = (String) questionmarks.subSequence(0, questionmarks
				.length() - 1);

		String query = SQL_INSERT.replaceFirst(TABLE_REGEX, tableName);
		query = query.replaceFirst(VALUES_REGEX, questionmarks);

		System.out.println("Query: " + query);

		Connection con = null;
		PreparedStatement ps = null;
		int successCount = 0;
		int failureCount = 0;
		try {
			con = this.connection;
			con.setAutoCommit(false);
			ps = con.prepareStatement(query);

			Date date = null;
			List<String[]> fillRecords = fills;

			for (String[] nextLine : fillRecords) {
				if (null != nextLine) {
					int index = 1;
					for (String string : nextLine) {
						date = DateUtil.convertToDate(string);
						if (null != date) {
							ps.setDate(index++, new java.sql.Date(date.getTime()));
						} else {
							ps.setString(index++, string);
						}
					}
					try {
						ps.execute();
						++successCount;
					} catch(MySQLIntegrityConstraintViolationException duplicateException) {
						++failureCount;
						// Continue with other records
					}
				}
			}
			con.commit();
		} catch (Exception e) {
			con.rollback();
			e.printStackTrace();
			throw new Exception(
					"Error occured while loading data from file to database."
							+ e.getMessage());
		} finally {
			if (null != ps)
				ps.close();
			if (null != con)
				con.close();
		}
		System.out.println("successCount" + successCount);
		System.out.println("failureCount" + failureCount);
	}

	public char getSeprator() {
		return seprator;
	}

	public void setSeprator(char seprator) {
		this.seprator = seprator;
	}
	
	public static String[] getFillRecord(String tradeId, String side, String size, String price, BITYPE bitype, String bitProduct) {
		
		String[] fillRecord = new String[10];
		fillRecord[0] = tradeId;
		fillRecord[1] = bitProduct;
		fillRecord[2] = side;
		fillRecord[3] = null;
		fillRecord[4] = size;
		fillRecord[5] = bitype.name();
		fillRecord[6] = price;
		fillRecord[7] = "";
		fillRecord[8] = "";
		fillRecord[9] = "";
		
		return fillRecord;
	}
	
	public void initiateLoad(List<String[]> fills) {
		try {
			loadData("order", false, fills);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

}
