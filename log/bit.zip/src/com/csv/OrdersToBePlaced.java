package com.csv;

import java.util.List;

import com.bit.coin.Trade;

public class OrdersToBePlaced {

	private int buyOrdersToDo;
	private int sellOrdersToDo;
	private int lastBuyOrderNumber;
	private int lastSellOrderNumber;
	private List<String> recentBuyPrices;
	private List<String> recentSellPrices;
	private List<Trade> buyTrades;
	private List<Trade> sellTrades;
	
	public List<Trade> getBuyTrades() {
		return buyTrades;
	}
	public void setBuyTrades(List<Trade> buyTrades) {
		this.buyTrades = buyTrades;
	}
	public List<Trade> getSellTrades() {
		return sellTrades;
	}
	public void setSellTrades(List<Trade> sellTrades) {
		this.sellTrades = sellTrades;
	}
	public int getBuyOrdersToDo() {
		return buyOrdersToDo;
	}
	public void setBuyOrdersToDo(int buyOrdersToDo) {
		this.buyOrdersToDo = buyOrdersToDo;
	}
	public int getSellOrdersToDo() {
		return sellOrdersToDo;
	}
	public void setSellOrdersToDo(int sellOrdersToDo) {
		this.sellOrdersToDo = sellOrdersToDo;
	}
	public int getLastBuyOrderNumber() {
		return lastBuyOrderNumber;
	}
	public void setLastBuyOrderNumber(int lastBuyOrderNumber) {
		this.lastBuyOrderNumber = lastBuyOrderNumber;
	}
	public int getLastSellOrderNumber() {
		return lastSellOrderNumber;
	}
	public void setLastSellOrderNumber(int lastSellOrderNumber) {
		this.lastSellOrderNumber = lastSellOrderNumber;
	}
	public List<String> getRecentBuyPrices() {
		return recentBuyPrices;
	}
	public void setRecentBuyPrices(List<String> recentBuyPrices) {
		this.recentBuyPrices = recentBuyPrices;
	}
	public List<String> getRecentSellPrices() {
		return recentSellPrices;
	}
	public void setRecentSellPrices(List<String> recentSellPrices) {
		this.recentSellPrices = recentSellPrices;
	}
	
}
